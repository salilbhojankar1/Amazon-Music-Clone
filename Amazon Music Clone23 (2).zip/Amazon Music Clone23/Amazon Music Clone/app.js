const music = new Audio('on_my_way.mp3');

// create Array

const songs = [
    {
        id:'1',
        songName:'On My Way <br><div class="subtitle">Alan Walker</div>',
        poster:"img/1.jpg"
    },
    {
        id:'2',
        songName:'Alan Walker-Fade <br><div class="subtitle">Alan Walker</div>',
        poster:"img/3.webp"
    }
]

Array.from(document.getElementsByClassName('songItem')).forEach((element, i)=>{
element.getElementsByTagName('img')[0].src = songs[i].poster;
})