package service;

import model.Admin;

public interface AdminService {
	public Admin addAdmin(Admin admin);
}
